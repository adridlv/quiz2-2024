var express = require('express');
require('dotenv').config({path: './env/.env'})

var app = express();

app.get('/', function (req, res) {
    res.send(`El ${process.env.TEAM_NAME} ha resuelto el ejercicio`);
});

app.listen(8080, function () {
    console.log('Dummy webapp running on port 8080!');
});